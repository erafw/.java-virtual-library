package biblioteca;

import java.util.LinkedList;

public class Main {
    public static void main(String[] args) {
        // ===== Semana 2: Lista de Livros =====
        LinkedList<Livro> listaLivros = new LinkedList<>();

        // Adicionando livros
        Livro l1 = new Livro("O Senhor dos Anéis", "J.R.R. Tolkien", 1954);
        Livro l2 = new Livro("Dom Casmurro", "Machado de Assis", 1899);
        Livro l3 = new Livro("1984", "George Orwell", 1949);

        listaLivros.add(l1);
        listaLivros.add(l2);
        listaLivros.add(l3);

        System.out.println("📚 Lista de livros:");
        for (Livro livro : listaLivros) {
            System.out.println(livro);
        }

        listaLivros.removeIf(livro -> livro.getTitulo().equals("Dom Casmurro"));

        System.out.println("\n📚 Lista após remoção:");
        for (Livro livro : listaLivros) {
            System.out.println(livro);
        }

        System.out.println("\nPrimeiro livro: " + listaLivros.getFirst());
        System.out.println("Último livro: " + listaLivros.getLast());

        // ===== Semana 3: Fila de Espera =====
        System.out.println("\n==== Fila de Espera ====");
        FilaEspera fila = new FilaEspera();
        fila.adicionarUsuario("Maria");
        fila.adicionarUsuario("João");
        fila.adicionarUsuario("Ana");
        fila.mostrarFila();
        fila.atenderUsuario();
        fila.mostrarFila();

        // ===== Semana 3: Histórico de Navegação =====
        System.out.println("\n==== Histórico de Navegação ====");
        HistoricoNavegacao historico = new HistoricoNavegacao();
        historico.visualizarLivro(l1);
        historico.visualizarLivro(l2);
        historico.visualizarLivro(l3);
        historico.mostrarHistorico();
        historico.voltarUltimoLivro();
        historico.mostrarHistorico();

        // ===== Semana 4: Grafo de Recomendações =====
        System.out.println("\n==== Grafo de Recomendações ====");
        Grafo grafo = new Grafo();

        // Criando 10 livros
        Livro a1 = new Livro("O Senhor dos Anéis", "J.R.R. Tolkien", 1954);
        Livro a2 = new Livro("Dom Casmurro", "Machado de Assis", 1899);
        Livro a3 = new Livro("1984", "George Orwell", 1949);
        Livro a4 = new Livro("Harry Potter", "J.K. Rowling", 1997);
        Livro a5 = new Livro("A Revolução dos Bichos", "George Orwell", 1945);
        Livro a6 = new Livro("Memórias Póstumas de Brás Cubas", "Machado de Assis", 1881);
        Livro a7 = new Livro("O Hobbit", "J.R.R. Tolkien", 1937);
        Livro a8 = new Livro("Capitães da Areia", "Jorge Amado", 1937);
        Livro a9 = new Livro("O Pequeno Príncipe", "Antoine de Saint-Exupéry", 1943);
        Livro a10 = new Livro("A Divina Comédia", "Dante Alighieri", 1320);

        // Adicionando livros ao grafo
        grafo.adicionarLivro(a1);
        grafo.adicionarLivro(a2);
        grafo.adicionarLivro(a3);
        grafo.adicionarLivro(a4);
        grafo.adicionarLivro(a5);
        grafo.adicionarLivro(a6);
        grafo.adicionarLivro(a7);
        grafo.adicionarLivro(a8);
        grafo.adicionarLivro(a9);
        grafo.adicionarLivro(a10);

        // Criando recomendações (cada livro recomenda pelo menos 2 outros)
        grafo.adicionarRecomendacao(a1, a7);
        grafo.adicionarRecomendacao(a1, a3);

        grafo.adicionarRecomendacao(a2, a6);
        grafo.adicionarRecomendacao(a2, a8);

        grafo.adicionarRecomendacao(a3, a5);
        grafo.adicionarRecomendacao(a3, a9);

        grafo.adicionarRecomendacao(a4, a1);
        grafo.adicionarRecomendacao(a4, a9);

        grafo.adicionarRecomendacao(a5, a3);
        grafo.adicionarRecomendacao(a5, a10);

        grafo.adicionarRecomendacao(a6, a2);
        grafo.adicionarRecomendacao(a6, a8);

        grafo.adicionarRecomendacao(a7, a1);
        grafo.adicionarRecomendacao(a7, a4);

        grafo.adicionarRecomendacao(a8, a2);
        grafo.adicionarRecomendacao(a8, a6);

        grafo.adicionarRecomendacao(a9, a3);
        grafo.adicionarRecomendacao(a9, a4);

        grafo.adicionarRecomendacao(a10, a5);
        grafo.adicionarRecomendacao(a10, a9);

        // Mostrar recomendações de alguns livros
        grafo.mostrarRecomendacoes(a1);
        grafo.mostrarRecomendacoes(a3);
        grafo.mostrarRecomendacoes(a9);
    }
}
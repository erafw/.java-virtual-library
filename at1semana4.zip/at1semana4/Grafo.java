package biblioteca;

import java.util.*;

public class Grafo {
    private Map<Livro, Set<Livro>> grafo;

    public Grafo() {
        grafo = new HashMap<>();
    }

    // Adicionar um livro ao grafo
    public void adicionarLivro(Livro livro) {
        grafo.putIfAbsent(livro, new HashSet<>());
    }

    // Criar relação (aresta) entre dois livros
    public void adicionarRecomendacao(Livro origem, Livro destino) {
        grafo.putIfAbsent(origem, new HashSet<>());
        grafo.putIfAbsent(destino, new HashSet<>());
        grafo.get(origem).add(destino);
    }

    // Mostrar recomendações de um livro
    public void mostrarRecomendacoes(Livro livro) {
        Set<Livro> recomendacoes = grafo.get(livro);
        if (recomendacoes == null || recomendacoes.isEmpty()) {
            System.out.println("Nenhuma recomendação para: " + livro);
        } else {
            System.out.println("Recomendações para " + livro + ":");
            for (Livro l : recomendacoes) {
                System.out.println(" - " + l);
            }
        }
    }
}
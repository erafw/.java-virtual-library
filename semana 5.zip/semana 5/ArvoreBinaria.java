package biblioteca;

public class ArvoreBinaria {
    private NoArvore raiz;

    public ArvoreBinaria() {
        this.raiz = null;
    }

    // Inserir livro na árvore
    public void inserir(Livro livro) {
        raiz = inserirRecursivo(raiz, livro);
    }

    private NoArvore inserirRecursivo(NoArvore atual, Livro livro) {
        if (atual == null) {
            return new NoArvore(livro);
        }
        if (livro.getTitulo().compareToIgnoreCase(atual.livro.getTitulo()) < 0) {
            atual.esquerda = inserirRecursivo(atual.esquerda, livro);
        } else if (livro.getTitulo().compareToIgnoreCase(atual.livro.getTitulo()) > 0) {
            atual.direita = inserirRecursivo(atual.direita, livro);
        }
        return atual;
    }

    // Buscar livro pelo título
    public Livro buscar(String titulo) {
        return buscarRecursivo(raiz, titulo);
    }

    private Livro buscarRecursivo(NoArvore atual, String titulo) {
        if (atual == null) {
            return null;
        }
        if (titulo.equalsIgnoreCase(atual.livro.getTitulo())) {
            return atual.livro;
        }
        return titulo.compareToIgnoreCase(atual.livro.getTitulo()) < 0
                ? buscarRecursivo(atual.esquerda, titulo)
                : buscarRecursivo(atual.direita, titulo);
    }

    // Percorrer em ordem (in-order)
    public void listarEmOrdem() {
        listarRecursivo(raiz);
    }

    private void listarRecursivo(NoArvore atual) {
        if (atual != null) {
            listarRecursivo(atual.esquerda);
            System.out.println(atual.livro);
            listarRecursivo(atual.direita);
        }
    }
}